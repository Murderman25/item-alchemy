package ml.pkom.itemalchemy.util;

import ml.pkom.mcpitanlibarch.api.entity.Player;
import net.minecraft.item.ItemStack;

public interface ItemCharge {

}
