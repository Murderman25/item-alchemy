# Item Alchemy (English)
## Overview
This MOD adds philosopher's stone etc. which can be equivalently exchanged with EMC system like ProjectE.

## Download
- https://www.curseforge.com/minecraft/mc-mods/item-alchemy-fabric
- https://modrinth.com/mod/item-alchemy

## Wiki
- https://wikichree.com/pitan76/?Item+Alchemy/en

----

# Item Alchemy (日本語)
## 概要
このMODはProjectEのようなEMCシステムと等価交換できる賢者の石などを追加します。

## ダウンロード
- https://www.curseforge.com/minecraft/mc-mods/item-alchemy-fabric
- https://modrinth.com/mod/item-alchemy

## ウィキ
- https://wikichree.com/pitan76/?Item+Alchemy
